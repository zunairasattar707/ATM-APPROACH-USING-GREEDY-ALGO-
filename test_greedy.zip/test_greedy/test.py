import time

# Function to simulate ATM withdrawal using the Greedy Algorithm
def atm_withdrawal(amount, denominations):
    denominations.sort(reverse=True)  # Sort denominations in descending order
    result = {}
    for denom in denominations:
        if amount >= denom:
            count = amount // denom
            result[denom] = count
            amount -= count * denom

    if amount > 0:
        return None  # Amount cannot be dispensed with the given denominations
    return result

# Main function
def main():
    # Available denominations in the ATM
    denominations = [5000, 1000, 500, 100, 50, 20, 10]

    print("Welcome to the ATM Simulator!")
    try:
        amount = int(input("Enter the amount you want to withdraw: "))
        if amount <= 0:
            print("Invalid amount. Please enter a positive value.")
            return

        # Measure running time
        start_time = time.time()
        result = atm_withdrawal(amount, denominations)
        end_time = time.time()

        if result:
            print("\nWithdrawal successful! Here is the breakdown:")
            for denom, count in result.items():
                print(f"{denom} x {count}")
        else:
            print("\nThe requested amount cannot be dispensed with the available denominations.")

        # Time complexity explanation and running time
        print("\nTime Complexity: O(n) (where n is the number of denominations)")
        print(f"Running Time: {end_time - start_time:.6f} seconds")
    except ValueError:
        print("Invalid input. Please enter a numeric value.")

if __name__ == "__main__":
    main()